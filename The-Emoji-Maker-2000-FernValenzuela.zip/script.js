//*******************Properties************************
const myEmojis = ["🏋️ ", "🎮", "🔧"]
const emojiBank = document.getElementById("emoji-element")
const emojiInput = document.getElementById("emoji-input")
const pushButton = document.getElementById("push-button")
const unshiftButton = document.getElementById("unshift-button")
const popButton = document.getElementById("pop-button")
const shiftButton = document.getElementById("shift-button")

//*********************EndofProperties*******************

function displayEmojis()  {
  emojiBank.innerHTML = ""
  for (let i = 0; i < myEmojis.length; i++) {
  const emoji = document.createElement("span")
  emoji.textContent = myEmojis[i]
  emojiBank.append(emoji)
  }

}

displayEmojis()

pushButton.addEventListener("click", function(){
  if (emojiInput.value)  {
    myEmojis.push(emojiInput.value)
    emojiInput.value = ""
    displayEmojis()
  }
})
  

unshiftButton.addEventListener("click", function(){
  if (emojiInput.value)  {
    myEmojis.unshift(emojiInput.value)
    emojiInput.value = ""
    displayEmojis()
  } 
})

popButton.addEventListener("click", function(){
  myEmojis.pop()
    displayEmojis()
})

shiftButton.addEventListener("click", function(){
  myEmojis.shift()
    displayEmojis()
})

