# Instructions  
(A good emoji reference guide is here: https://emojiguide.org)

#1

1. Take a look at the array of emojis in script.js. Your first job: loop through the array and log each emoji to the console.

2.  Fetch the emoji-element div and store it in a variable. Log this to the console.

---

#2

Make the unshift button work. It is the same as the push button, but use unshift.

---

#3

Code the “Remove from the end” button to remove the emoji on the end. Code the “Remove from the beginning” button to remove the emoji from the beginning